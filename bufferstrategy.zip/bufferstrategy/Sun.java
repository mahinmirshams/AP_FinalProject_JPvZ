package game.bufferstrategy;

import java.awt.*;
import java.util.TimerTask;

/**
 * Created by saeedehspg on 6/23/2016 AD.
 */
public class Sun extends Drawable{


    @Override
    int getStateToVisible() {
        return 2;
    }
    public Sun(int x, int y) {
        super(x,y,"Sun_pvZ2.png",70, 70);

    }

    @Override

    public void draw(Graphics2D g2d , GameState gameState) {
        try {
            super.draw(g2d,gameState);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        y += 1;
    }

    @Override
    void onclicked(GameState gameState) {
        super.onclicked(gameState);
        gameState.money+=25;
        gameState.itemsToDelete.add(this);
    }

    @Override
    public void random() {
        super.random();

    }

}


