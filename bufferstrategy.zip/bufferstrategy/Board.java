package game.bufferstrategy;

import java.util.ArrayList;

/**
 * Created by saeedehspg on 6/25/16.
 */
public class Board  {
    int x;
    int y;
    public Board(int x,int y){
        x =this.x;

    }
}
