package game.bufferstrategy;

/**
 * Created by saeedehspg on 6/23/2016 AD.
 */
public class PeaShooter extends Drawable {
    @Override
    int getStateToVisible() {
        return 2;
    }
    public PeaShooter(int x, int y) {
        super(x,y,"Repeater_HD_HD.png",70, 100);

    }
}
