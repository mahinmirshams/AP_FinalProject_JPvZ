package game.bufferstrategy;

import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by saeedehspg on 6/23/2016 AD.
 */
public class PeaShooter extends GameObject {
    @Override
    int getStateToVisible() {
        return 2;
    }
    public PeaShooter(int x, int y, GameState state) {
        super(x,y,"Peashooter_HD.png",70, 100, state ,0,100);

    }

    @Override
    void planted() {
        super.planted();
//        Random rand = new Random();
//        int value = rand.nextInt(4000);
        final PeaShooter me = this;
        TimerTask Task = new TimerTask() {
            @Override
            public void run() {
                Pea icedPea = new Pea(me, gameState);
                gameState.drawables.add((icedPea));

            }

        };
        Date day = new Date();
        Timer timer = new Timer();
        timer.schedule(Task ,day.getSeconds(),4000);

        new  Pea(this,gameState);

    }
}

