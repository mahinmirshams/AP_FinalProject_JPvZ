package game.bufferstrategy;

/**
 * Created by saeedehspg on 6/26/2016 AD.
 */
public class Pea extends GameObject {
    public Pea(PeaShooter peaShooter, GameState gameState) {
        super(peaShooter.x + 40, peaShooter.y + 10, "Pea.png", 20, 20, gameState, -2, Integer.MAX_VALUE);
    }

    @Override
    int getStateToVisible() {

        return 2;
    }

    @Override
    void update() {
        super.update();
      GameObject gameObject = getCollidedObject();
        if(gameObject!=null && gameObject instanceof Zombie){
            gameObject.hurt(50);
            life = 0;
        }
    }
}


