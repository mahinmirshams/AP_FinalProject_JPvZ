package game.bufferstrategy;

/**
 * Created by saeedehspg on 6/23/16.
 */
 import java.io.FileInputStream;

        import javazoom.jl.player.Player;

public class Sound extends Thread {

    private int num;

    public Sound() {
        // TODO Auto-generated constructor stub
    }

    @Override
    public void run() {

            // TODO Auto-generated method stub
            try {
                FileInputStream file = new FileInputStream("/Users/masihyeganeh/IdeaProjects/jpvz/src/images/level1.mp3");
                Player playMP3 = new Player(file);
                playMP3.play(100);
            } catch (Exception e) {
                System.out.println("not   sounddddddddddddddddddddddddddddddddddddddddddddddd");
            }

    }

}