package game.bufferstrategy;

/**
 * Created by mahin mirshams on 6/26/2016.
 */
public class WalNutPicker extends PlantsPicker {

    public WalNutPicker(int x, int y, GameState state) {
        super(x, y, "WalNutPicker.jpg", "WalNut.png", state);
    }

    @Override
    int getValue() {
        return 50;
    }

    @Override
    void onclicked(GameState gameState) {
        super.onclicked(gameState);
        if (gameState.money >= getValue())
            gameState.selectedItem = new WalNut(0, 0 , gameState);

    }
}
