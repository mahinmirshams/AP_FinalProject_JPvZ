package game.bufferstrategy;

import game.bufferstrategy.Drawable;

import java.awt.*;

/**
 * Created by saeedehspg on 6/22/16.
 */
public class Plants extends Drawable {
    public Plants(int x, int y) {
        super(x,y,"Repeater_HD_HD.png", 75, 50);


    }


}



