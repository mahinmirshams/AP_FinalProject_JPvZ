package game.bufferstrategy;

import java.awt.*;
import java.util.Date;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by saeedehspg on 6/21/2016 AD.
 */
public class Zombie extends GameObject{

    Timer freezeTimer = new Timer();

    @Override
    int getStateToVisible() {
        return 2;
    }

    public Zombie(int x, int y,GameState state) {
        super(x, y, "ZombieHD.png", 70, 100,state, 2,100);
    }

    @Override
    void update() {
        if (gameState.states == 2) {
            super.update();
            if (x <= 300) {
                for (Drawable drawable : gameState.drawables) {
                    if (drawable instanceof LawnMover && ((LawnMover) drawable).y <= 200) {
                        ((LawnMover) drawable).changeSpeed(-2);
                    }
                }
            }
        }

    }

    @Override
    GameObject getCollidedObject() {
        return super.getCollidedObject();

    }


    @Override
    void hurt(int strength) {
        super.hurt(strength);
        }

    TimerTask unfreeze = new TimerTask() {
        @Override
        public void run() {

            img = Main.loadImage("ZombieHD.png");
            changeSpeed(speed*2);
            freezeTimer.cancel();

        }

    };

    void getIcy(String icyName){
        freezeTimer.cancel();
        this.img = Main.loadImage(icyName);
        this.changeSpeed(speed/2);
        freezeTimer.schedule(unfreeze, 8000);
    }

}

