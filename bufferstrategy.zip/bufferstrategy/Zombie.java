package game.bufferstrategy;

import java.awt.*;

/**
 * Created by saeedehspg on 6/21/2016 AD.
 */
public class Zombie extends Drawable {
    private int loc ;
    @Override

    int getStateToVisible() {
        return 2;
    }

    public Zombie(int x, int y) {
        super(x, y, "ZombieHD.png", 70, 100);

    }

    public Zombie() {

    }


    @Override
    public void draw(Graphics2D g2d, GameState gameState) {
        try {
            super.draw(g2d, gameState);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        if (x > 393) {
            x -= 5;
            loc = x;
            System.out.println("loc : " + loc);
        }
        else x = 393;
        if (x == 393) {
            gameState.states = 3;
            gameState.itemsToDelete.add(this);
            deleteZombie(x,gameState);
            gameState.states =4;

        }
    }

    public int getLoc() {
        return loc;
    }

    public void deleteZombie(int x , GameState state) {
        if (x==this.x){
            state.items2Delete.add(this);
            state.itemsToDelete.add(this);
        }
    }
}
