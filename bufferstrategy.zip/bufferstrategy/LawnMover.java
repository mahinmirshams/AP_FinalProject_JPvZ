package game.bufferstrategy;

import java.awt.*;
import java.util.ArrayList;
import java.util.Iterator;

/**
 * Created by saeedehspg on 6/21/2016 AD.
 */
public class LawnMover extends Drawable {

    Zombie zombie = new Zombie();
    ArrayList <Zombie> zombies ;


    public LawnMover(int x, int y, ArrayList<Zombie> zombies) {
        super(x,y,"Lawn_Mower.png",100, 85);
        this.zombies = zombies;

    }


    @Override
    public void draw(Graphics2D g2d, GameState state) throws InterruptedException {
        Iterator < Zombie>  it = zombies.iterator() ;
        while(it.hasNext())
        {
            Zombie z = it.next() ;
            if (x==z.x){
                zombie.deleteZombie(x,state);
                System.out.print("sss");
            }

        }
        super.draw(g2d, state);
        if (state.states>=3){
            x+=2;

        }
        it = zombies.iterator() ;
        while(it.hasNext())
        {
            Zombie z = it.next() ;
            System.out.println("zz  : " + z.getLoc());
//            Systeem.out.println("lawnmover  :  " + x);
            if (x==z.getLoc()){
                zombie.deleteZombie(x,state);
                System.out.print("sss");
            }

        }
    }


}
