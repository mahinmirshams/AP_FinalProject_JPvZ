package game.bufferstrategy;

/**
 * Created by mahin mirshams on 6/26/2016.
 */
public class CherryBomb extends GameObject {

    @Override
    int getStateToVisible() {
        return 2;
    }
    public CherryBomb(int x, int y, GameState state) {
        super(x,y,"CherryBomb.png",70, 100, state ,0,100);
           }

}
