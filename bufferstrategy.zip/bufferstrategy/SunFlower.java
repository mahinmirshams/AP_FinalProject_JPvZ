package game.bufferstrategy;

import java.util.Date;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by saeedehspg on 6/23/2016 AD.
 */
public class SunFlower extends GameObject {
    @Override
    int getStateToVisible() {
        return 2;
    }

    public SunFlower(int x, int y, GameState state) {
        super(x,y,"sunflower.gif",70, 100, state,0,100);
        makeSun();

    }

    public void makeSun(){
        Random rand = new Random();
        int value = rand.nextInt(4000);
        final SunFlower me = this;
        TimerTask Task = new TimerTask() {
            @Override
            public void run() {

                Sun sun = new Sun(me , gameState); //
                gameState.drawables.add(sun);
            }

        };
        Date day = new Date();
        Timer timer = new Timer();
        timer.schedule(Task ,day.getSeconds(),4000);
    }


}
