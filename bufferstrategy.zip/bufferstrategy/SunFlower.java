package game.bufferstrategy;

/**
 * Created by saeedehspg on 6/23/2016 AD.
 */
public class SunFlower extends Drawable {
    @Override
    int getStateToVisible() {
        return 2;
    }
    public SunFlower(int x, int y) {
        super(x,y,"sunflower.gif",70, 100);

    }
}
